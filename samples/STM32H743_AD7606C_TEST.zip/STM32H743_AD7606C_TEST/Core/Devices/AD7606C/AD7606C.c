#include "AD7606C.h"

uint16_t AD7606C_Data[8 * MAX_SIZE];
float AD7606C_VoltData[8][MAX_SIZE];

uint16_t AD7606C_Init(uint16_t *P, uint16_t Range, uint16_t Bandwidth, uint16_t OverSamp)
{
	uint16_t ID = 0;
	// ���ò�����Χ
	*P = Range1_Adress | Range;
	HAL_Delay(1);
	*P = Range2_Adress | Range;
	HAL_Delay(1);
	*P = Range3_Adress | Range;
	HAL_Delay(1);
	*P = Range4_Adress | Range;
	HAL_Delay(1);
	// ���ô���
	*P = Bandwidth_Adress | Bandwidth;
	HAL_Delay(1);
	// ���ù�����
	*P = Oversampling_Adress | OverSamp;
	HAL_Delay(1);
	// ��ȡID
	*P = 0x8000 | Name_ID_Adress;
	HAL_Delay(1);
	//	ID = *P;
	HAL_Delay(1);
	// �ָ�ADCģʽ
	*P = 0x0000;

	return 0;
}

/**
 * @brief AD7606C DMA interrupt initialize, this function can reset the DMA interrupt compeletly.
 * @param htim The timer handle
 * @param hdma The dma interrupt handle
 * @param Channel The square wave output Channel1
 * @note htim and hdma could be found in tim.h
 */
void AD7606C_Init_IT(TIM_HandleTypeDef* htim, DMA_HandleTypeDef* hdma, uint32_t Channel){
	HAL_DMA_Abort_IT(hdma); // ����ж�
	__HAL_TIM_ENABLE_DMA(htim, TIM_DMA_UPDATE); // ʹ��tim����DMA
	HAL_DMA_Start_IT(hdma, ADDR, (uint32_t)AD7606C_Data,MAX_SIZE*8);  // ʹ���жϣ�����������
	HAL_TIM_PWM_Start(htim, Channel); // ����PWM���
	HAL_TIM_Base_Start(htim); // ����TIM
}

/**
 * @brief AD7606C Data Analyse function, can change origin data to voltage value.
 * @return After this function, all data will be in AD7606C_VoltData array.
 * 		   AD7606C_VoltData[i][j] means the jth datapoint of the Channel (i + 1), which i is 1 ~ 8.
 */
void AD7606C_DataAnalyse()
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < MAX_SIZE; j++)
		{
			if (AD7606C_Data[j * 8 + i] >= 32768)
				AD7606C_VoltData[i][j] = (float)AD7606C_Data[j * 8 + i] / 65536 * 20 - 20;
			else
				AD7606C_VoltData[i][j] = (float)AD7606C_Data[j * 8 + i] / 65536 * 20;
		}
	}
}

/**
 * @brief Copy the result of one of the channels into another float array.
 * @param target copy target
 * @param channel the id of the required channel(1 ~ 8)
 */
void AD7606C_ReadData(float* target, int channel){
	for(int i = 0; i < MAX_SIZE; ++i){
		target[i] = AD7606C_VoltData[channel - 1][i];
	}
}
